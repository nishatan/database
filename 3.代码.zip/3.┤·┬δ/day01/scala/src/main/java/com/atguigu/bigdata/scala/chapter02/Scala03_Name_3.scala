package com.atguigu.bigdata.scala.chapter02

object Scala03_Name_3 {

    def main(args: Array[String]): Unit = {

        val `private` = "私有的"
        println(`private`)

        Thread.`yield`()

    }
}
