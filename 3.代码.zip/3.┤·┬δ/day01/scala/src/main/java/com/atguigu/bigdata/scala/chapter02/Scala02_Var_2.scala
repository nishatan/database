package com.atguigu.bigdata.scala.chapter02

object Scala02_Var_2 {

    def main(args: Array[String]): Unit = {

        // TODO 变量
        // scala中声明变量一定要初始化
        val name : String = "123"


    }
}
