package com.atguigu.bigdata.scala.chapter02

object Scala03_Name_2 {
    def test(): Unit = {
        println("test..")
    }
    def main(args: Array[String]): Unit = {

        // TODO 标识符
        // 马丁在编译时，将特殊符号编译为转换的变量名，这个变量名以$开头的。
        // 一般情况下，标识符起名时不能使用$开头

        // 颜文字
        //val :-> = "lisi"
        //val > = "lisi"
        //val $greater = "lisi"

        //println(:->)

        // TODO 下划线在scala中的作用非常丰富
        //val _ = "wangwu"
        //println(_)


    }
}
