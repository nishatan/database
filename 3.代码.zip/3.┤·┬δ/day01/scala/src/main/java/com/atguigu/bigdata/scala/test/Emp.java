package com.atguigu.bigdata.scala.test;

public class Emp {
    public final static int age = 30;
    static {
        System.out.println("emp static init...");
    }
}
