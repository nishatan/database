package com.atguigu.bigdata.scala.chapter02

object Scala03_Name {

    def main(args: Array[String]): Unit = {

        // TODO 标识符
        // scala的标识符和java的标识符基本一致
        /*
          1. 数字，字母，下划线，$
          2. 数字不能开头
          3. 不能使用关键字或保留字
          4. 区分大小写
          5. 长度没有限制

             _name(70~80)
             name
         */
        val name = "zhangsan"
        val name1 = "zhangsan"
        val name$ = "zhangsan"
        val name_ = "zhangsan"
        val Private = "zhangsan"
        //val private = "zhangsan"(X)
        //val 1name_ = "zhangsan"(X)

        // 计算规则（运算符）



    }
}
