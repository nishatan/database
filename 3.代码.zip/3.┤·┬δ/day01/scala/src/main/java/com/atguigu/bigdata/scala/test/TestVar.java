package com.atguigu.bigdata.scala.test;

public class TestVar {
    public static void main(String[] args) {

        String name;

        name = "123";
        System.out.println(name);
    }
}
