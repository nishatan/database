package com.atguigu.bigdata.scala.test;

import com.atguigu.bigdata.scala.chapter02.Scala03_Name_2;

public class TestObject {
    public static void main(String[] args) {

        Scala03_Name_2.test();

    }
}
