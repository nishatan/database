package com.atguigu.bigdata.scala.chapter02

object Scala02_Var_1 {

    def main(args: Array[String]): Unit = {

        // TODO 变量
        // 强类型的语言中，类型的声明应该前后统一，如果我明确的知道变量的取值是多少，那么变量的类型就确定了。
        // 马丁说：我能猜出来的语法，你不要写了，我帮你。
        // 能够通过取值推断变量的类型，那么变量类型可以省略
        // 如果使用多态，那么类型不能省略
        var name : String = "zhangsan"
        var name1 : Object = "lisi"
        println(name1)


    }
}
