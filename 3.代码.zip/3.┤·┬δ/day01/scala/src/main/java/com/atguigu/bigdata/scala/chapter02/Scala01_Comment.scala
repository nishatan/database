package com.atguigu.bigdata.scala.chapter02

object Scala01_Comment {

    def main(args: Array[String]): Unit = {

        // TODO 注释
        // 单行注释
        /*
           多行注释
         */
        /**
         * 文档注释
         */


    }
}
