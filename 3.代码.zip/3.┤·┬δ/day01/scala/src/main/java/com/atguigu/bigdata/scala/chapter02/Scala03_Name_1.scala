package com.atguigu.bigdata.scala.chapter02

object Scala03_Name_1 {

    def main(args: Array[String]): Unit = {

        // TODO 标识符
        // Scala中的标识符不用记，错了改就行了。

        // Scala中的标识符可以用于声明运算符
        val + = "zhangsan"
        val - = "zhangsan"
        val * = "zhangsan"
        val ~ = "zhangsan"
        val ! = "zhangsan"
        val @@ = "zhangsan"
        val ## = "zhangsan"
        val $ = "zhangsan"
        val % = "zhangsan"
        val ^ = "zhangsan"
        val & = "zhangsan"
        val < = "zhangsan"
        val > = "zhangsan"
        val ? = "zhangsan"
        //val `` = "zhangsan"
        val :: = "zhangsan"
        val ::: = "zhangsan"
        // 颜文字
        val :-> = "lisi"

        println(:->)


    }
}
