package com.atguigu.bigdata.scala.test;

public class TestThread {
    public static void main(String[] args) throws Exception{

        Thread t1 = new Thread();
        Thread t2 = new Thread();

        t1.start();
        t2.start();

        // TODO 字体不一样
        // sleep => 静态方法 => 和类有关，和对象无关
        // wait  => 成员方法 => 和对象有关
        t1.sleep(1000); // t1线程没有休眠，main线程在休眠
        t2.wait(1000);  // t2线程在等待



    }
}
