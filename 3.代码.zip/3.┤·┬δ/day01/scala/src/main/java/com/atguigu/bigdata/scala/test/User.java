package com.atguigu.bigdata.scala.test;

public class User {
    public static int age;
    static {
        age = 30;
        System.out.println("user static init...");
    }
}
