package com.atguigu.bigdata.scala.chapter01

object Scala01_HelloWorld {

    def main(args: Array[String]): Unit = {

        System.out.println("Hello Scala World")

    }
}
