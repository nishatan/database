package com.atguigu.bigdata.scala.chapter02

object Scala02_Var {

    def main(args: Array[String]): Unit = {

        // TODO 变量
        // java中变量声明  => String name = "zhangsan";
        // scala中变量声明(1) => var 变量名 : 变量的类型 = 变量的值
        var name1 : String = "zhangsan"
        name1 = "lisi"

        // 一个变量在某些场合中，一旦初始化后就不能重新赋值
        // scala中变量声明(2) => val 变量名 : 变量的类型 = 变量的值
        val name2 : String = "lisi"
        //name2 = "wangwu"

        //println(name)


    }
}
