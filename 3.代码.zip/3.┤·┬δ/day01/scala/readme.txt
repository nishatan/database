下划线的作用

1. 声明变量，但是不能访问

   val _ = "zhangsan"