package com.atguigu.bigdata.scala.chapter02

import com.atguigu.bigdata.scala.test.User

object Scala07_DataType_3 {

    def main(args: Array[String]): Unit = {

        // TODO 数据类型
        //Object obj = new User()
        //obj = new Emp()

        var a : Any = "123"

        a = 1


    }
}
