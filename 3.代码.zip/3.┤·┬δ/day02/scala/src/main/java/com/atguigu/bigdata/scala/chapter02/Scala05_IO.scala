package com.atguigu.bigdata.scala.chapter02

import scala.io.{BufferedSource, Source, StdIn}

object Scala05_IO {

    def main(args: Array[String]): Unit = {

        // TODO IO
        // read - 控制台
        //val line: String = StdIn.readLine()
        //println(line)

        // 从文件中获取输入
        // 数据源
        // TODO 文件路径
        // 绝对路径：不可改变的路径
        //     本地路径：file:///c:/test/test.txt
        //     网络路径：http://www.xxx.com
        // 相对路径：可以改变的路径,一定存在一个基准路径
        //     ./ => 当前路径（可以省略）
        //    ../ => 当前路径的上一级路径
        // IDEA中基准路径为项目的根路径
        val source: BufferedSource = Source.fromFile("data/word.txt")
        val strings: Iterator[String] = source.getLines()
        while ( strings.hasNext ) {
            println(strings.next())
        }

        source.close()

    }
}
