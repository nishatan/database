package com.atguigu.bigdata.scala.test;

public class TestFlow {
    public static void main(String[] args) {
        String name = "zhangsan";
        System.out.println(name);

        test();

    }
    public static void test() {

    }
}
