package com.atguigu.bigdata.scala.chapter02

object Scala07_DataType_5 {

    def main(args: Array[String]): Unit = {

        // 编译器将类型进行了转换，所以可以编译通过
        // 这个转换开发人员看不见，将这样的转换称之为隐式转换
        //val b : Byte = 20
        //val i : Int = b
        //val b : Byte = 'A'
        //val c : Char = b + 1
        //println(c)
    }

}
