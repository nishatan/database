package com.atguigu.bigdata.scala.chapter02

object Scala04_String {

    def main(args: Array[String]): Unit = {

        // TODO 字符串的拼接
        // select 'name' + num from user

        //val name = "zhangsan"

        //println("Hello" + name)

        // JSON => JavaScript Object Notation
        // JSON字符串 => 符合JSON格式的字符串

        // 网络中传递的数据是什么？
        val name = "zhangsan"
        val password = "123123"

        //val json = "{\"username\":\""+name+"\", \"password\":\""+password+"\"}"
        //println(json)

        // 传值字符串
        //printf("username : %s\n", name)
        //printf("password : %s", password)

        // 插值字符串
        //println(s"username : $name")

        // 官方无法使用插值字符串封装JSON
        //val json1 = s"{\"username\":\"${name}\", \"password\":\"${password}\"}"
        //println(json1)

        // 多行字符串
        // 竖线表示顶格符
        val s =
            """
              | Hello
                Scala
              |""".stripMargin('#')

        val json =
            s"""
              | { "username":"${name}", "password":"${password}" }
              |""".stripMargin

        val sql = "select id from (select * from t_user where id = 1 order by id desc) a group by id"

        val sql1 =
            """
              | select
              |    id
              | from
              |    (
              |        select
              |           *
              |        from t_user
              |        where id = 1
              |        order by id desc
              |
              |    ) a
              | group by id
              |
              |""".stripMargin

        println(json)

    }
}
