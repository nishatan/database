package com.atguigu.bigdata.scala.test;

import static com.atguigu.bigdata.scala.test.Emp.*;

public class TestStatic {
    public static void main(String[] args) {

        System.out.println(age);

        // 静态导入
        test();

    }
}
