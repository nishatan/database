package com.atguigu.bigdata.scala.chapter04

object Scala01_Flow {

    def main(args: Array[String]): Unit = {

        // TODO 流程
        // 基本的数据操作流程，从前到后
        //Str
        //println(name)

        //val name = "zhangsan"
    }
}
