package com.atguigu.bigdata.scala.chapter04

object Scala04_Flow_while {

    def main(args: Array[String]): Unit = {

        var age = 0

        while ( age < -1 ) {
            println("*******" + age)
            age += 1
        }

        do {
            println("######" + age)
            age += 1
        } while (age < -1)

    }
}
