package com.atguigu.bigdata.scala.chapter04

object Scala03_Flow_for_2 {

    def main(args: Array[String]): Unit = {

        // TODO for循环
        // 表达式的返回值
        val result = for ( i <- 1 to 5 ) yield {
            i * 2
        }
        println(result)

    }
}
