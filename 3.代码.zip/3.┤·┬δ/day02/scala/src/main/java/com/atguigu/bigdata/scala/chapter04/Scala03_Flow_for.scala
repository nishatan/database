package com.atguigu.bigdata.scala.chapter04

object Scala03_Flow_for {

    def main(args: Array[String]): Unit = {

        // TODO for循环
        /*

          java

          for ( int i = 0; i < 10; i=i+2 ) {
              sout(i)
          }
          // JDK 1.5
          //for ( Object obj : list ) {
          for ( list : Object obj  ) {
              sout(obj)
          }

         */
        // Scala 循环

        //val range = 1.to(5)
        //val range = 1 to(5)
        // to方法包含结束的数据，但是Range的第二个参数(until)不包含
        //val range = 1 to 5 by 2
        //val range = 1 until 5 by 2
        //val range = Range(1, 5, 2)

//        for ( i : Int <- range ) {
//            println(i)
//        }
//        for ( i <- range ) {
//            println(i)
//        }

        for ( i <- Range(5, 1, -1) ) {
            println(i)
        }

    }
}
