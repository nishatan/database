package com.atguigu.bigdata.scala.chapter02

import scala.io.{BufferedSource, Source}

object Scala07_DataType {

    def main(args: Array[String]): Unit = {

        // TODO 数据类型
        // 任意值类型
        val b : Byte = 20
        val s : Short = 20
        val c : Char = 'a'
        val i : Int = 20
        val lon : Long = 20
        val f : Float = 20.0F
        val d : Double = 20.0
        val flg : Boolean = true
        val u : Unit = test() // Unit是一个类型，这个类型只有一个对象，打印就是小括号
        println(u)

    }
    def test(): Unit = {

    }
}
