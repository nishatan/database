package com.atguigu.bigdata.scala.chapter04

object Scala03_Flow_for_3 {

    def main(args: Array[String]): Unit = {

        // TODO for循环
        // 表达式的返回值
        for (i <- 1 to 18 by 2; j = (18 - i)/2) {
            println(" " * j + "*" * i)
        }

    }
}
