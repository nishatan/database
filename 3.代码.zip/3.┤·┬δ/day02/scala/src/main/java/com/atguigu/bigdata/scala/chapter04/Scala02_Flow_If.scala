package com.atguigu.bigdata.scala.chapter04

object Scala02_Flow_If {

    def main(args: Array[String]): Unit = {

        // TODO 流程
        // 分支判断
        val age = 40
//        if ( age == 30 ) {
//            println("年龄等于30")
//        } else {
//            println("其他")
//        }

        if ( age < 18 ) {
            println("少年")
        } else if ( age < 36 ) {
            println("青年")
        } else if ( age < 45 ) {
            println("壮年")
        } else if ( age < 55 ) {
            println("中年")
        } else {
            println("老年")
        }

    }
}
