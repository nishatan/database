package com.atguigu.bigdata.scala.chapter02

object Scala07_DataType_6 {

    def main(args: Array[String]): Unit = {

        // 编译器将类型进行了转换，所以可以编译通过
        // 这个转换开发人员看不见，将这样的转换称之为隐式转换
        //val b : Byte = 20
        //val i : Int = b
       // val b : Byte = 'A'
        //val c : Char = b + 1
        //println(c)

        // 所有的类型都可以转换为字符串
        val b : Byte = 20

        //b.toString
        //b.to

        // 字符串也可以转换为数值
        val s = "123a"
        val i = s.toInt
        println(i)
    }

}
