package com.atguigu.bigdata.scala.test;

public class TestException {
    public static void main(String[] args) {

        // TODO 如果调用了一个为空（null）对象的成员属性或成员方法，会产生空指针异常
        UserX user = new UserX();
        test(user.age);
        // Integer => 自动拆箱(Integer.intValue) => int

    }
    public static void test( int age ) {
        System.out.println(age);
    }
}
class UserX {
    public static Integer age;
}
