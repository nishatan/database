package com.atguigu.bigdata.scala.test;

public class TestFor {
    public static void main(String[] args) {

        java.util.List list = null;

        for (Object obj : list) {
            System.out.println(obj);
        }
    }
}
