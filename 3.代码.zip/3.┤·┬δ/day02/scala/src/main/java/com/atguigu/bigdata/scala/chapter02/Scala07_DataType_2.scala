package com.atguigu.bigdata.scala.chapter02

import com.atguigu.bigdata.scala.test.User

object Scala07_DataType_2 {

    def main(args: Array[String]): Unit = {

        // TODO 数据类型
        // User user = new User();
        // User user = null;
        //val i : Int = null
        // Null在scala中是一个类型，只有一个对象，就是null
        val n = null
        val user : User = null

        //val i : Int = null


    }
}
