package com.atguigu.bigdata.scala.chapter02

import com.atguigu.bigdata.scala.test.User

object Scala07_DataType_1 {

    def main(args: Array[String]): Unit = {

        // TODO 数据类型

        val list : AnyRef = List(1,2,3,4)
        val obj : AnyRef = new User()
        val obj1 : AnyRef = Scala07_DataType_1

        println(list)
        println(obj)
        println(obj1)


    }
}
