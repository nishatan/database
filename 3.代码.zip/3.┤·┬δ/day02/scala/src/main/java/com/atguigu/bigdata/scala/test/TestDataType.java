package com.atguigu.bigdata.scala.test;

public class TestDataType {
    public static void main(String[] args) {

        // java中的基本数据类型没有类型的概念，有精度的概念
        // 0000 0001 => byte
        // 0000 0000 0000 0001 => short
        // 0000 0000 0000 0000 0000 0000 0000 0001 => int
        //byte b = 1;
        //test(b);

        //char c = 'A' + 1;
        //char c = 66;
        //System.out.println(c);

        // 常量计算是在编译时完成
        //int i = 10 + 10 + 10;

        // 0000 0000 0000 0000 0000 0000 0000 0001 => int
        //                               0000 0001 => byte
        //int i = 100;
        //byte b = (byte)i; // 截取精度

        byte b = 127;
        //b++; // 一元运算符不会提升数据类型
        byte b1 = (byte)(b + 1);
        System.out.println(b1);

        // 0111 1111
        // 0000 0000 0000 0000 0000 0000 1000 0000
        //                               1000 0000 = -128

        // 1 + 1111111 => 8位数据中负数的最大值 => -1
        // 1 + 0000000 => 8位数据中负数的最小值 => -128
        // 10000001    => -127




    }












//    public static void test(byte b) {
//        System.out.println("bbbb");
//    }
//    public static void test(short s) {
//        System.out.println("ssss");
//    }
    public static void test(char c) {
        System.out.println("cccc");
    }
//    public static void test(int i) {
//        System.out.println("iiii");
//    }
}
