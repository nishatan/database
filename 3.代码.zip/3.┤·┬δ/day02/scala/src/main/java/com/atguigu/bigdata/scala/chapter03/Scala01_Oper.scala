package com.atguigu.bigdata.scala.chapter03

object Scala01_Oper {

    def main(args: Array[String]): Unit = {

        // TODO 运算符
        val s1 = new String("abc")
        //val s1 : String = null
        val s2 = new String("abc")

        // 马丁想：判断两个对象的内存地址的意义
        // 判断对象是否相等，双等号会更加直观
        // scala语法中双等号就是比较对象的内容,但是和equals不一样。是非空equals操作
        println( s1 == s2 )
        println( s1.equals(s2) )
        println( s1.eq(s2) ) // eq方法在编译后就是java中的双等号

        val s = "abc" * 2
        println(s)
    }
}
