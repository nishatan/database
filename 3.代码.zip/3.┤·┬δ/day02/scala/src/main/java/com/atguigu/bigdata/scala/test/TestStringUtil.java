package com.atguigu.bigdata.scala.test;

public class TestStringUtil {
    public static void main(String[] args) {

        System.out.println(isNotEmpty(null));
    }
    public static boolean isNotEmpty(String s) {
        return s != null  &  !s.trim().equals("");
    }
}
