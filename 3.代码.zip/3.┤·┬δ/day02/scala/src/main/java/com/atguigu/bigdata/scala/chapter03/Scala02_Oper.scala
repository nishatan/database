package com.atguigu.bigdata.scala.chapter03

import com.atguigu.bigdata.scala.test.User

object Scala02_Oper {

    def main(args: Array[String]): Unit = {

        // TODO 运算符
        // new User()
        // scala是一个完全面向对象的语言，数字也是对象
        val r = 10.+(10)
        val j = 10 + 10
        val k = "abc".*(2)
        // 马丁想
        // 1. 方法在调用时，可以省略点
        // 2. 方法如果参数只有一个或没有，那么小括号可以省略
        val user = new User()
        println(user toString)
    }
}
