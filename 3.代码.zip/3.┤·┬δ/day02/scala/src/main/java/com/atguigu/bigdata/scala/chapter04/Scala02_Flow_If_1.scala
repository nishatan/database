package com.atguigu.bigdata.scala.chapter04

object Scala02_Flow_If_1 {

    def main(args: Array[String]): Unit = {

        // TODO 流程
        val age = 30
        // TODO 表达式的返回结果为：表达中满足条件的最后一行代码的执行结果
        val result = if ( age == 30 ) {
            "zhangsan"
        } else {
            null
        }

        //println(re)

    }
}
