package com.atguigu.bigdata.scala.chapter04

object Scala03_Flow_for_1 {

    def main(args: Array[String]): Unit = {

        // TODO for循环
        // TODO 循环守卫
//        for ( i <- Range(1,5) if i != 3  ) {
//            println("%%%%%%%%%")
//            println("i = " + i )
//        }
//        println("************************************")
//        for ( i <- Range(1,5)   ) {
//            println("########")
//            if (i != 3) {
//
//                println("i = " + i )
//            }
//        }

        // TODO 循环嵌套
//        for ( i <- Range(1,3); j <- Range(1,1) ) {
//            println("i = " + i + ",j = " + j )
//        }
//        println("***********************************")
//        for ( i <- Range(1,3) ) {
//            for ( j <- Range(1,1) ) {
//                println("i = " + i + ",j = " + j )
//            }
//        }

        // TODO 引入变量
        for ( i <- Range(1,5); j = i - 1 ) {
            println("j = " + j )
        }

    }
}
