package com.atguigu.bigdata.scala.chapter06

object Scala10_Object_Abstract_3 {

    def main(args: Array[String]): Unit = {

        // TODO 面向对象 - 抽象

        // 子类可以重写父类的抽象属性，补充完整即可
        // 子类可以重写父类的完整属性，那么必须要添加override关键字
       // println(new Child().age)

        println(new Child().test)


    }
    abstract class User {
        var name : String
        val age : Int = 10

        def test(): Unit = {
            //age = 30 // 对属性的赋值其实等同于调用属性的set方法
            println(age) // 对属性的方法其实等同于调用属性的get方法
        }
    }
    class Child extends User {
        var name : String = "zhangsan" // 重写
        override val age : Int = 20
    }
}