package com.atguigu.bigdata.scala.chapter07

import java.util
import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object Scala03_Collection {

    def main(args: Array[String]): Unit = {

        // TODO - 集合 - 方法
        val array = Array(1,2,3,4)

        println(array.size)
        println(array.length)
        println(array.isEmpty)
        println(array.contains(2))
        println(array.distinct.mkString(","))
        println(array.reverse.mkString(","))

        println(array.mkString(","))
        array.foreach(println)
        array.iterator





    }
}
