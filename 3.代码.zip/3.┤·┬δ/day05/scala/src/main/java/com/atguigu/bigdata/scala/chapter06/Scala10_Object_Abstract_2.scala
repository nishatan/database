package com.atguigu.bigdata.scala.chapter06

object Scala10_Object_Abstract_2 {

    def main(args: Array[String]): Unit = {

        // TODO 面向对象 - 抽象

        // 子类重写父类的抽象方法，直接补充完整即可
        // 子类重写父类的完整方法，必须添加override关键字
        // 开发时，推荐，只要重写，都添加override



    }
    abstract class User {
        def test(): Unit = {

        }
        def fun():Unit
    }
    class Child extends User {
        override def test(): Unit = {

        }
        override def fun():Unit = {

        }
    }
}