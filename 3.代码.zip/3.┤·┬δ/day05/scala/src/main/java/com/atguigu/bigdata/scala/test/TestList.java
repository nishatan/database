package com.atguigu.bigdata.scala.test;

import java.util.ArrayList;

public class TestList {
    public static void main(String[] args) {

       // new ArrayList().forEach();

    }
}
