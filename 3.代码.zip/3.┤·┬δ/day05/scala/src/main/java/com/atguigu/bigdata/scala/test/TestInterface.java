package com.atguigu.bigdata.scala.test;

public class TestInterface {
    public static void main(String[] args) {

        IIII iiii = new BBBB(); // 多态的传递



        System.out.println(iiii);
        System.out.println(BBBB.class.getInterfaces().length);

        // 接口和当前类有关，和父，子类没有任何的关系
    }
}
interface IIII {

}
class AAAA implements IIII {

}
class BBBB extends AAAA {

}
