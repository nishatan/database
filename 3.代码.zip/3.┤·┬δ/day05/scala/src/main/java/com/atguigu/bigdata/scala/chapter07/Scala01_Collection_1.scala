package com.atguigu.bigdata.scala.chapter07

object Scala01_Collection_1 {

    def main(args: Array[String]): Unit = {

        // TODO - 集合 - 数组
        // 集合分为两大类：可变集合，不可变集合
        // Scala默认提供的集合都是不可变。
//        val array = new Array[String](3)
//        array(0) = "a"
//        array(1) = "a"
//        array(2) = "a"
        // 使用集合的伴生对象构建集合，并同时初始化
        val array1 = Array(1,2,3,4)
        val array2 = Array(5,6,7,8)
        //val array2 = Array.apply(1,2,3,4)

        // 访问
        //val ints: Array[Int] = array1.+:(5)
        // scala中如果运算符是以冒号结尾，那么运算规则为从后向前计算
        val ints = 5 +: array1

        //val ints1: Array[Int] = array1.:+(5)
        val ints1 = array1 :+ 5

        val ints2 = array1 ++ array2
        val ints3 = array1 ++: array2

        //println(array1 eq ints)
        //println(array1 eq ints1)
       // println(ints eq ints1)


        // TODO 遍历
        //println(ints.mkString(","))
        //println(ints1.mkString(","))
        //println(ints2.mkString(","))

        // foreach方法是一个循环的方法，需要传递一个参数，这个从参数的类型是函数类型
        //  函数类型 ： Int => U
        def foreachFunction(num:Int): Unit = {
            println(num)
        }

        //array1.foreach(foreachFunction)
        //array1.foreach((num:Int)=>{println(num)})
        //array1.foreach((num:Int)=>println(num))
        //array1.foreach((num)=>println(num))
        //array1.foreach(num=>println(num))
        array1.foreach(println(_))
    }
}
