package com.atguigu.bigdata.scala.test

class ScalaUser extends java.io.Serializable {
    var name:String = _
}
object ScalaUser {
    var email:String = _
}
