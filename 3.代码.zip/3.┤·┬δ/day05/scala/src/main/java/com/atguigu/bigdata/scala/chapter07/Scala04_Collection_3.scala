package com.atguigu.bigdata.scala.chapter07

import scala.collection.mutable.ArrayBuffer

object Scala04_Collection_3 {

    def main(args: Array[String]): Unit = {

        // TODO - 集合 - 方法
//        val array = ArrayBuffer(1,2,3,4)
//
//        // 根据指定的规则对每一条数据进行分组
//        val r = array.groupBy(
//            num => {
////                if ( num % 2 == 0 ) {
////                    "偶数"
////                } else {
////                    "奇数"
////                }
//                num % 2
//            }
//        )
//
//        println(r)
        val array = ArrayBuffer(
            "Hello", "Scala", "Hadoop", "Spark"
        )

        println(array.groupBy(_.substring(0, 1)))


    }

}
