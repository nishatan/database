package com.atguigu.bigdata.scala.chapter06

import java.lang.reflect.Field

object Scala13_Object_String {

    def main(args: Array[String]): Unit = {

        val s = " a b "

        // 反射：类型信息
        // 镜子
        val stringClass: Class[String] = classOf[String]
        val field: Field = stringClass.getDeclaredField("value")
        field.setAccessible(true)
        val obj = field.get(s)
        val chars: Array[Char] = obj.asInstanceOf[Array[Char]]
        chars(2) = 'D'

        println(s)


    }
}