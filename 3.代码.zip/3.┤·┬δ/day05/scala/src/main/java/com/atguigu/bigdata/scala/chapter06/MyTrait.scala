package com.atguigu.bigdata.scala.chapter06

trait MyTrait {

}
object MyTrait {

}
