package com.atguigu.bigdata.scala.chapter07

import scala.collection.mutable.ArrayBuffer

object Scala03_Collection_1 {

    def main(args: Array[String]): Unit = {

        // TODO - 集合 - 方法
        val array = ArrayBuffer(1,2,3,4)

        // 从集合中获取部分数据
        println(array.head)
        println(array.tail)
        println(array.tails)
        println(array.last)
        println(array.init) // 初始
        println(array.inits)

        // 取前几个
        println(array.take(3))
        //println(array.reverse.take(2).reverse)
        println(array.takeRight(2))
        println(array.drop(1))
        println(array.dropRight(1))






    }
}
