package com.atguigu.bigdata.scala.chapter06

import java.lang.reflect.Field

object Scala15_Object_App extends App {

    println("aaaa")
    println("bbbb")
    println("cccc")
}