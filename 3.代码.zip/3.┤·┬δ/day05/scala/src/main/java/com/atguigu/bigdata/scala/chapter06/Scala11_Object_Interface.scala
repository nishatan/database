package com.atguigu.bigdata.scala.chapter06

object Scala11_Object_Interface {

    def main(args: Array[String]): Unit = {

        // TODO 面向对象 - 接口

        // 马丁将接口从scala中去除了。


    }
}