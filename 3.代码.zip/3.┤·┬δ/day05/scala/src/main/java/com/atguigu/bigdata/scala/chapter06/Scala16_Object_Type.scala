package com.atguigu.bigdata.scala.chapter06


object Scala16_Object_Type extends App {
   
    type JavaKVMap = java.util.HashMap[String, String]

    private val map: JavaKVMap = new JavaKVMap()
}