package com.atguigu.bigdata.scala.chapter06

object Scala12_Object_Trait_2 {

    def main(args: Array[String]): Unit = {

        // TODO 面向对象 - 特征(特质)
        // 可以将trait理解为接口和抽象类的结合体
        new User()

    }

    trait Test extends Exception {
        def test(): Unit
    }
    class Person{

    }
    class User extends Test {
        override def test(): Unit = {

        }
    }
}