package com.atguigu.bigdata.scala.chapter06

object Scala09_Object_Instance_3 {

    def main(args: Array[String]): Unit = {

        new User("zhangsan");

        // aaaaa
        // ccccc

    }
    class Person(s:String) {
        println("aaaaa")
        def this() {
            this("lisi")
            println("bbbbb")
        }
    }
    class User(var name:String) extends Person(name){
        println("ccccc")
        def this() {
            this("wangwu")
            println("ddddd")
        }
    }
}