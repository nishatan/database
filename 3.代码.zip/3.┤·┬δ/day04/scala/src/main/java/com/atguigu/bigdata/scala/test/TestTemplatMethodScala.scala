package com.atguigu.bigdata.scala.test

object TestTemplatMethodScala {

    def main(args: Array[String]): Unit = {

//        TM.execute {
//            println("do execute query")
//        }
        TM.execute {
            println("do execute insert")
        }
    }
    object TM {
        def execute( op : => Unit ): Unit = { // 父类将算法的骨架搭建好
            startTransaction()

            op

            endsTransaction()
        }

        private def startTransaction(): Unit = {
            System.out.println("startTransaction")
        }

        private def endsTransaction(): Unit = {
            System.out.println("endsTransaction")
        }
    }
}
