package com.atguigu.bigdata.scala.test;

public class TestOverride {
    public static void main(String[] args) {

        // TODO 方法的重写
        // 子类重写父类的方法
        // 如何区分父类，子类中相同的方法，需要采用TODO 动态绑定机制
        // 在调用对象的成员方法过程中，将方法和对象的实际内存进行绑定，然后调用
        A1 a1 = new A1();
        //System.out.println(a1.sum()); // 20

        B1 b1 = new B1();
        //System.out.println(b1.sum()); // 40

        A1 a2 = new B1();
        //System.out.println(a2.sum()); // 40

        A1 a3 = new B1();
        // 属性是不遵循动态绑定机制，所以在哪里声明，在哪里使用
        System.out.println(a3.sum()); // 20

    }
}
class A1 {
    public int i = 10;
    public int sum() {
        return getI() + 10; //父类中使用的属性居然在子类中声明？
    }
    public int getI() {
        return i;
    }
}
class B1 extends A1 {
    public int i = 20;
//    public int sum() {
//        return i + 20;
//    }
    public int getI() {
        return i;
    }
}
