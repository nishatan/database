package com.atguigu.bigdata.scala.test;

public class TestTemplateMethod {
    public static void main(String[] args) {

        Parent parent = getParent();
        parent.doExecute();
    }
    private static Parent getParent() {
        return new OperChild();
    }
}
abstract class Parent {
    public void execute() {
        // 父类将算法的骨架搭建好
        startTransaction();
        doExecute(); // 子类只需要实现具体的细节即可。
        endsTransaction();
    }
    private void startTransaction() {
        System.out.println("startTransaction");
    }
    private void endsTransaction() {
        System.out.println("endsTransaction");
    }
    abstract protected void doExecute(); //{
        //System.out.println("doExecute");
   // }
}
class QueryChild extends Parent {
    @Override
    protected void doExecute() {
        System.out.println("do execute query");
    }
}
class OperChild extends Parent {
    @Override
    protected void doExecute() {
        System.out.println("do execute insert/update/delete");
    }
}
