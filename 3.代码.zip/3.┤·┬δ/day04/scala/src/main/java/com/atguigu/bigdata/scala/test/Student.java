package com.atguigu.bigdata.scala.test;

public class Student extends Person {
    public String name = "student";

    public void test() {
        System.out.println(super.name);
        System.out.println(this.name);
    }
}
