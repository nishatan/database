package com.atguigu.bigdata.scala.chapter06

object Scala09_Object_Instance_2 {

    def main(args: Array[String]): Unit = {

        /*
          class User {
              private String name;
              public User( String name ) {
                  this.name = name;
              }
          }
         */
        // TODO 在构造参数前使用var或val声明
        val user = new User("zhangsan");
        user.name = "wangwu"

    }
    class User(var name:String) {
        //var username : String = name
    }
}