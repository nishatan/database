package com.atguigu.bigdata.scala.test;

public class TestOverload {
    public static void main(String[] args) {

        // 方法的重载
        // 名称（参数列表）
        // 如果对应的类型没有查找到，会找对应的通用类型
        //AAA aaa = new AAA();
        //BBB bbb = new BBB();
        BBB aaa = new BBB();
        test(aaa);
    }
    public static void test( AAA aaa ) {
        System.out.println("aaa");
    }
//    public static void test( BBB bbb ) {
//        System.out.println("bbb");
//    }
}
class AAA {

}
class BBB extends AAA {

}
