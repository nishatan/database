package com.atguigu.bigdata.scala.test;

import java.util.*;

public class TestImport {
    public static void main(String[] args) {
        new ArrayList();
    }
}
