package com.atguigu.bigdata.scala.test;

public class TestAccess {
    public static void main(String[] args) throws Exception {

        // 访问权限
        // 所谓的访问权限：其实就是权力和限制
        // 用户和系统的关系
        // 方法的调用者和方法的提供者之间的关系
        // 方法的提供者 => com.atguigu.bigdata.scala.test.AA
        // 方法的调用者 => com.atguigu.bigdata.scala.test.TestAccess

        // 点不是调用的意思，点的含义就是"的",从属关系
        AA aa = new AA();
        aa.clone();

        // User user = new User();
        // user.name = "zhangsan"

        Student s = new Student();
        s.test();
    }
}
class AA {
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
