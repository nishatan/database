package com.atguigu.bigdata.scala.test

class ScalaUser {
    var name:String = _
}
object ScalaUser {
    var email:String = _
}
