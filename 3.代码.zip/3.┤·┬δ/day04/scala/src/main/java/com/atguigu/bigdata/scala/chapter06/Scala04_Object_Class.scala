package com.atguigu.bigdata.scala.chapter06

object Scala04_Object_Class {

    def main(args: Array[String]): Unit = {

        // TODO 面向对象 - 类
        // 使用class关键字可以声明类

        // 通过new的方式构建类的对象
        // scala中的源码可以声明多个类，而且可以声明多个公共类，名称可以和文件名不一样。
        val test = new Test();


    }
    class Test {

    }
}