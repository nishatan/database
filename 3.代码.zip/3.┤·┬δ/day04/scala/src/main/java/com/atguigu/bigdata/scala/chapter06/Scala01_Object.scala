package com.atguigu.bigdata.scala.chapter06

object Scala01_Object {

    def main(args: Array[String]): Unit = {

        // TODO  - 面向对象编程
        /*

        package xxx.yyy.zzz
        import java.util.List

        public class Test {
            private String name;
            public void setName() {

            }
        }

        Test test = new Test();
        test.setName();

         */
        val test = new Test()
        test.test()

    }
    class Test {
        def test(): Unit = {

        }
    }
}
