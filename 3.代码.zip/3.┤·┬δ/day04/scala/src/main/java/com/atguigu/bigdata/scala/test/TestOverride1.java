package com.atguigu.bigdata.scala.test;

public class TestOverride1 {
    public static void main(String[] args) {

        // TODO 方法的重写

        A2 a2 = new B2();
        System.out.println(a2.sum()); // 20

    }
}

class A2 {
    public static int i = 10;
    public static int sum() {
        return i+ 10; //父类中使用的属性居然在子类中声明？
    }
}

class B2 extends A2 {
    public static int i = 20;
    public static int sum() {
        return i + 20;
    }
}
