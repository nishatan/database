package com.atguigu.bigdata.scala

package object chapter06 {
    def testPackageObject(): Unit = {
        println("test package object...")
    }
}
