package com.atguigu.bigdata.scala.chapter06

object Scala08_Object_Object {

    def main(args: Array[String]): Unit = {

        // TODO 面向对象 - 类 - 对象
        val user = new User();
        // 1. 反射
        // 2. new
        // 3. 反序列化
        // 4. clone

        // Kafka高吞吐消息系统
        // 零拷贝


    }
    class User {

    }
}