package com.atguigu.bigdata.scala.test;

public class Person {
    public String name = "person";
}
