package com.atguigu.bigdata.scala.test;

public class TestString {
    public static void main(String[] args) {

        // String字符串是不可变
        // String类没有提供任何改变内容的方法,所以是不可变的字符串类型。
        // 所有的字符串操作的方法都会产生新的字符串

        // trim方法用于去掉字符串的首尾半角空格。

        // !,!
        // !，!
//        String s = " a b ";
//        s = s.trim();
//        System.out.println("!"+s+"!");
        // !a b!
        // ! a b ! (OK)
        // !ab!

        new java.lang.String();


    }
}
