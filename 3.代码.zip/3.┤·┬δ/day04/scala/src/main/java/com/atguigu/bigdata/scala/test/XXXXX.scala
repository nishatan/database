package com.atguigu.bigdata.scala.test

class XXXXX {

}
