package com.atguigu.bigdata.scala.test;

public class Dept {
    public String name;
}
