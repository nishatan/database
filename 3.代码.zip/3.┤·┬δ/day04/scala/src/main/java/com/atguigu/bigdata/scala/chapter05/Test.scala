package com.atguigu.bigdata.scala.chapter05

import com.atguigu.bigdata.scala.chapter06.Scala06_Object_Access.Test6

object Test {

    def main(args: Array[String]): Unit = {
        //new Test6().na
    }
}
