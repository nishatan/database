下划线的作用

1. 声明变量，但是不能访问

   val _ = "zhangsan"

2. 将函数作为整体使用

   val f = fun1 _

3. 使用import语法时，下划线可以代替星号

    import java.util._

4. 使用import语法时，下划线可以隐藏类

    import java.sql.{Date->_}