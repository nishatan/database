package com.atguigu.bigdata.scala.chapter05

object Scala09_Function {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 递归
        //   1. scala中要求递归函数必须明确声明返回值类型
        //   2. 函数内部调用自身
        //   3. 一定要有跳出递归的逻辑
        //   4. 递归函数在调用时传递的参数之间有关系
        // 阶乘
        // 5!
        // StackOverflowError
        // Overflow : 滚动
//        def myRecursion(num:Int):Int = {
//            if ( num <= 1 ) {
//                1
//            } else {
//                num * myRecursion(num-1)
//            }
//        }
//
//        println(myRecursion(5))

        def myRecursion(num:Long):Long = {
            if ( num <= 1 ) {
                1
            } else {
                num + myRecursion(num-1)
            }
        }

        println(myRecursion(10000))

    }
}
