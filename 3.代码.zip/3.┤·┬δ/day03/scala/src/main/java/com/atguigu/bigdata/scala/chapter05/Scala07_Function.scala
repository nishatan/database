package com.atguigu.bigdata.scala.chapter05

import scala.util.control.Breaks

object Scala07_Function {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 地狱版


        // TODO : 控制抽象
        // 抽象
        // 函数类型：() =>Unit
        def myWhile(op: => Boolean) = {
            op
        }

        // 参数类型不完整，那么在传递参数时，也是不完整：只有传递代码就可以，不需要完整的声明
        // 可以采用控制抽象设计语法
        Breaks.breakable {
            for ( i <- 1 to 5 ) {
                Breaks.break()
            }
        }

//        val age = 10
//        myWhile( age < 20 ) {
//            println("xxx")
//        }
//
//
//        while( age < 20 ) {
//            println("xxx")
//        }

    }
}
