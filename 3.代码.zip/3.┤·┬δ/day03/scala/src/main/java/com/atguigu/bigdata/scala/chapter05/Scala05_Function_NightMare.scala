package com.atguigu.bigdata.scala.chapter05

object Scala05_Function_NightMare {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 噩梦版

        // 马丁（大神）想：程序员可以用愉悦的心情开发程序。
        //    逻辑简单，开发方便
        // 写程序时，如果编译器能识别的语法和逻辑，程序员就不需要去写
        // 能简单则简单，能简化则简化。TODO 能省则省 (至简原则)
        def test(): String = {
            return "zhangsan"
        }
        //println(test())

        // TODO 1. return 关键字可以省略
        // 函数体会将满足条件的最后一行的代码的执行结果作为函数的返回值
        def test1(): String = {
            "lisi"
        }
        //println(test1())

        // TODO 2. 如果函数返回数据，那么可以推断出返回值类型的话，返回值类型可以省略
        def test2() = {
            "wangwu"
        }

//        def test22() = {
//            val age = 30
//            if ( age == 30 ) {
//                "zhangsan"
//            } else {
//                null
//            }
//        }
       // println(test2())

        // TODO 3. 如果函数体的逻辑代码只有一行的，那么大括号可以省略
        def test3() = "wangwu1"
        //println( test3() )

        // TODO 4. 如果函数的参数列表中没有声明任何的参数，那么参数列表可以省略
        def test4 = "wangwu2"
        var test44 = "wangwu2"

        // 当函数省略参数列表的声明时，调用这个函数不能增加小括号的
        //println( test4 )

        // TODO 5. 如果希望省略Unit，但同时又不希望函数体中的return起作用，那么可以将等号同时省略
        // 如果函数明确声明为Unit，那么函数体中的return关键字不会被返回
        def test5(): Unit = {
            return "zhangsan"
        }
        // 如果函数体中使用return返回结果，那么一定要声明返回值类型
//        def test55() = {
//            return "zhangsan"
//        }
        // 过程函数
        def test555()  {
            return "zhangsan"
        }

        //def test5555() return "zhangsan"

        //println(test5())

        // TODO 6. 关键字def和函数名也可以省略，称之为匿名函数
        // 省略的同时，也需要将返回值类型同时省略，将等号增加一个箭头
        // 匿名函数不能独立使用
        //println(List(1, 2, 3, 4).reduce(_ - _))
        val f = () => {
            "zhangsan123"
        }

        println(f())
    }
}
