package com.atguigu.bigdata.scala.chapter05

object Scala04_Function_Normal {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程
        // TODO 1. 多参的个数?
        // (X)函数的参数最多只能有22个
        // 函数的参数没有限制
        def fun1(
                    a1:Int,
                    a2:Int,
                    a3:Int,
                    a4:Int,
                    a5:Int,
                    a6:Int,
                    a7:Int,
                    a8:Int,
                    a9:Int,
                    a10:Int,
                    a11:Int,
                    a12:Int,
                    a13:Int,
                    a14:Int,
                    a15:Int,
                    a16:Int,
                    a17:Int,
                    a18:Int,
                    a19:Int,
                    a20:Int,
                    a21:Int,
                    a22:Int,
                    a23:Int,
                    a24:Int,
                    a25:Int
                ): Unit = {
            //println("25 args...")
        }
        fun1(
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1
        )

        //val f = fun1 _

        // TODO 2. 参数的个数在某些情况下，不能固定
        //     可变（不确定）参数 : 参数类型后面增加星号
        //     可变参数在使用时，都是集合对象
        def fun2( name:String* ): Unit = {
            println(name)
        }

        //fun2(X)
        fun2() // 一个参数都没有 ： List()
        fun2("zhangsan") // 一个参数 WrappedArray(zhangsan)
        fun2("zhangsan", "lisi", "wangwu") // 一个参数 WrappedArray(zhangsan, lisi, wangwu)

        // TODO 可变参数必须放置在参数列表的最后
        def fun22( age:String, name:String* ): Unit = {

        }

        fun22("zhangsan", "xxxx")
    }
}
