package com.atguigu.bigdata.scala.chapter05

object Scala03_Function_Def {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程
        // TODO 1. 无参，无返回值
        def fun1(): Unit = {
            println("fun1...")
        }

        fun1()
        // 如果函数声明时，没有参数，那么调用时，可以省略小括号
        fun1

        // TODO 2. 无参，有返回值
        def fun2(): String = {
            return "zhangsan"
        }

        val r2 = fun2()
        println(r2)

        // TODO 3. 有参，无返回值
        // 参数的声明方式： 参数名：参数类型
        def fun3( name:String ): Unit = {
            println("name : " + name)
        }

        // 当函数有参数时，调用时，应该传递相同类型的参数
        1 + 1
        1 + 1

        fun3("lisi")
        // 函数的参数只有一个，也不能省略小括号
        // fun3 "lisi"(X)

        // TODO 4. 有参，有返回值
        def fun4( name:String ): String = {
            return "Name : " + name
        }

        val r4 = fun4( "wangwu" )
        println(r4)

        // TODO 5. 多参，无返回值
        def fun5( name:String, age:Int ): Unit = {
            println(s"Name : ${name}, Age : ${age}")
        }

        // 函数存在多个参数时，调用时应该匹配个数,类型,顺序
        // 匹配参数时，其实是按照顺序进行匹配
        // TODO java中方法参数的传递全部都是值传递
        fun5("zhangsan", 30)
        //fun5(30, "zhangsan")
        // TODO 6. 多参，有返回值
        def fun6( name:String, age:Int ): String = {
            val s = s"Name : ${name}, Age : ${age}"
            return s
        }

        val r6 = fun6("wangwu", 40)
        println(r6)


    }
}
