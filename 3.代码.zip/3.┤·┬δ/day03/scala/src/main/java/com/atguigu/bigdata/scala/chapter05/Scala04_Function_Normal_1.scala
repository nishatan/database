package com.atguigu.bigdata.scala.chapter05

object Scala04_Function_Normal_1 {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程
        // TODO 3. 参数默认值 : 声明参数的同时设定默认值
        //   底层就是编译为一个方法，当不传参数时，由编译器自动调用这个方法
        // 函数的参数默认以val声明，意味着不能改
//        def fun3( password:String ): Unit = {
//            var pswd = password
//            if ( pswd == null ) {
//                pswd = "000000"
//            }
//        }
        def fun3( password:String = "000000" ): Unit = {
            println(password)
        }

        // 调用时，参数如果想用使用默认值，可以不传递参数
        fun3()
        // 调用时，如果不想使用默认值，注解传值即可
        fun3("111111")
    }
}
