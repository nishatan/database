package com.atguigu.bigdata.scala.chapter05

object Scala06_Function_Hell_1 {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 地狱版
        /*
            public void test( User user ) {
            public void test( 函数类型 参数名称 ) {

            }

         */
        // TODO 2. 将函数作为参数来使用
//        def test(  f : ()=>Unit ): Unit = {
//            f()
//        }
//
//        // 函数对象
//        def fun1(): Unit = {
//            println("xxxxxxx")
//        }
//
//        val ff = fun1 _
//
//        test( ff )
        def test( f : (Int, Int) => Int ): Unit = {
            val r = f(10, 20)
            println(r)
        }
//
//        def fun2(x:Int, y:Int): Int = {
//            x + y
//        }
//        def fun3(x:Int, y:Int): Int = {
//            x - y
//        }
//        def fun4(x:Int, y:Int): Int = {
//            x * y
//        }
//
//        def fun5(x:Int, y:Int): Int = {
//            x + y
//        }

        //test(fun2)
        //test(fun3)
        //test(fun4)

        // TODO 匿名函数主要应用于函数作为参数使用
//        test(
//            (x:Int, y:Int) => {
//                x - y
//            }
//        )
        // TODO 匿名函数在使用时也可以存在至简原则
        // 1. 如果函数体的逻辑代码只有一行，大括号可以省略，代码写在一行中
//        test(
//            (x:Int, y:Int) => x - y
//        )
        // 2. 如果参数的类型可以推断出来，那么参数类型可以省略的
//        test(
//            (x, y) => x - y
//        )
        // 3. 如果参数只有一个的话，参数列表的小括号可以省略
        // 4. 如果参数在使用时，按照顺序只使用了一次，那么可以使用下划线代替参数，
        //test(_ * _)
    }
}
