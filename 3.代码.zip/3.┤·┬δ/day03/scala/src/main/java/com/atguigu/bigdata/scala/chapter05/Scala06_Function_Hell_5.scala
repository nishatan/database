package com.atguigu.bigdata.scala.chapter05

object Scala06_Function_Hell_5 {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 地狱版
        def test( x :Int, y:Int, f : (Int, Int)=>Int ): Unit = {
            val r = f(x, y)
            println(r)
        }

        //test(10, 20, _+_)
        test(10, 20,
            (x:Int, y:Int) => {
                x + y
            }
        )

    }
}
