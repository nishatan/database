package com.atguigu.bigdata.scala.chapter05

object Scala02_Function_Method_1 {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程
        def test(): Unit = {
            println("test function...")
        }
        // 函数的本质
        // 编译后，函数会被编译为一个新的方法
        //    private static final Unit test$1()

        // 如果函数名称和方法名称相同，那么调用时，默认为函数调用
        this.test()

    }
    def test(): Unit = {
        println("test method...")
    }
}
