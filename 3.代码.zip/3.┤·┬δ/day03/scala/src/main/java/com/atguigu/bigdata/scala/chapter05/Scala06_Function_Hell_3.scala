package com.atguigu.bigdata.scala.chapter05

object Scala06_Function_Hell_3 {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 地狱版
        def test( f : (Int, Int)=>Int ) = {
            f(10, 20)
        }

//        test(
//            (x:Int, y:Int) => {
//                x + y
//            }
//        )
//
//        test(
//            (x:Int, y:Int) => x + y
//        )

        println(
            test(
                (x, y) => 2 * x + y
            )
        )

        println(test(2*_ + _))

    }
}
