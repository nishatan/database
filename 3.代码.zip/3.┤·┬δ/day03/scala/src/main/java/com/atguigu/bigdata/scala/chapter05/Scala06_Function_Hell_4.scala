package com.atguigu.bigdata.scala.chapter05

object Scala06_Function_Hell_4 {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 地狱版
        def test( f : (String)=>Unit ): Unit = {
            f("zhangsan")
        }

        def fun(name:String): Unit = {
            println(name)
        }

        val f1 = fun _
        val f2 = fun _

        println(f1 eq f2)

        test(fun)

//        test(
//            (name:String) => {
//                println(name)
//            }
//        )
//        test(
//            (name:String) => println(name)
//        )
//        test(
//            (name) => println(name)
//        )
//        test(
//            name => println(name)
//        )
        test(println(_))

    }
}
