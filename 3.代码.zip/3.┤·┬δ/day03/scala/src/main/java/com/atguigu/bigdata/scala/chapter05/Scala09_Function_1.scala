package com.atguigu.bigdata.scala.chapter05

object Scala09_Function_1 {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 递归
        def test(): Unit = {
            test()
            println("test")
        }
        //test()

        // Scala中尾递归不是真正的递归，是由编译器进行了优化，形成了while循环。所以应该称之为伪递归
        // java中也有尾递归。但是不会优化为while循环。
        // 尾递归也会出现
        // 伪递归
        // 尾递归
        def test1(): Unit = {
            println("test")
            test1()
        }
        test1()

    }
}
