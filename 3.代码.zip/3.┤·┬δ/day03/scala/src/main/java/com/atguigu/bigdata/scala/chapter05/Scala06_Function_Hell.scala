package com.atguigu.bigdata.scala.chapter05

object Scala06_Function_Hell {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 地狱版

        // TODO 1. 函数也是个对象
        // User user = new User()
        //val f = ()=>{"zhangsan"}
        def fun1(): Unit = {
            println("fun1...")
        }

        val f1 = fun1 _
        //println("************")
        //val f2 = fun1()
        // 如果将函数作为整体，而不是执行结果赋值给变量，那么需要采用特殊符号：下划线
        //println("************")
        //f1()

        // 万物皆对象，但是对象都有类型，就意味着函数对象也有类型
        // 函数独立使用时，参数声明没有个数限制的，但是如果将函数作为对象给别人使用，那么函数的参数声明的个数最多为22个
        val f2 : Function0[Unit] = fun1 _
        //val f22 : Function22[] = fun1 _
        // 函数类型还有另外一种写法 ： （输入参数类型）=>输出类型
        val f3 : () => Unit = fun1 _

        //f1

        def test1( name:String, age:Int ):String = {
            "123"
        }

        // 之所以使用下划线让函数作为对象使用，因为代码中没有明确变量的类型，所以需要通过取值类推断
        // 如果变量声明的类型为函数类型，那么可以不使用下划线让函数作为对象
        val ff : (String, Int) => String = test1
        ff

        // (String) => String
        // (String, Int) => String
        // String => String


    }
}
