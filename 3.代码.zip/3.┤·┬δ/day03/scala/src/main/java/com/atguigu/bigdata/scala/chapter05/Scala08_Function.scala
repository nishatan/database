package com.atguigu.bigdata.scala.chapter05

import scala.util.control.Breaks

object Scala08_Function {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 柯里化（Curry）

        // 将无关的参数分离开
        def test( a:Int, b:Int ): Unit = {
            for ( i <- 1 to a ) { // 10min
                println(i)
            }
            for ( j <- 1 to b ) { // 20min
                println(j)
            }
        }

        def test1(a:Int)(b:Int): Unit = {
            for ( i <- 1 to a ) { // 10min
                println(i)
            }
            for ( j <- 1 to b ) { // 20min
                println(j)
            }
        }

        val a = 10 // 10min
        val b = 20 // 20min
        test(a, b) // 60min
        test1(a)(b)
    }
}
