package com.atguigu.bigdata.scala.test

object TestMethod {

    def main(args: Array[String]): Unit = {

        // TODO 1. 内部函数在外部使用的时候会有闭包
//        def test(a:Int) = {
//            def test(b:Int) = {
//                a + b
//            }
//            test _
//        }
//
//        test(10)(20)

        // TODO 2. 将函数作为对象使用，会有闭包
        // TODO 3. 所有的匿名函数都有闭包
        val age = 30
        def test(): Unit = {
            println(age + 20)
        }

        //test()
        val f = test _
        f()

    }
}
