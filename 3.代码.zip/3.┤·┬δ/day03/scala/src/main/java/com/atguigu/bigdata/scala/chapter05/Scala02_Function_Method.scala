package com.atguigu.bigdata.scala.chapter05

object Scala02_Function_Method {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程

        // 函数作用域比较窄
        // 方法的作用域比较大
        def test1(): Unit = {
            println("test function...")
        }

    }
    def test(): Unit = {
        println("test method...")
    }
    def test(name:String): Unit = {
        println("test method...")
    }
}
