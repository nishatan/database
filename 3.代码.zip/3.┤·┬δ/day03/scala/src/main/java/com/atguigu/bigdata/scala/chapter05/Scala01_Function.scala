package com.atguigu.bigdata.scala.chapter05

object Scala01_Function {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程
        //  scala语言是函数式编程语言，所以，万物皆函数，所以方法其实就是函数

        // TODO 声明方式
        // def 函数名(参数1:参数类型1, 参数2:参数类型2):函数返回值类型 = {函数体}

        def test1(): Unit = {
            println("test function...")
        }

        // 调用方式
        // 函数名（参数。。。）
        // TODO 函数式编程更看重什么？
        //    名称，输入，输出
        val r = test1()
        val r1 = Scala01_Function.test2()


    }
    def test2(): Unit = {
        println("test method...")
    }
}
