package com.atguigu.bigdata.scala.chapter05

object Scala06_Function_Hell_2 {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 地狱版
        def test( f : (String)=>Unit ): Unit = {
            f("zhangsan")
        }

        def fun( name:String ): Unit = {
            println(name)
        }
//
//        test(fun)
//        test(
//            ( name:String ) => {
//                println(name)
//            }
//        )
//        test(
//            ( name:String ) => println(name)
//        )
//        test(
//            ( name ) => println(name)
//        )
//        test(
//            name => println(name)
//        )
        test(println(_)) // 匿名函数的至简原则的最终版
        //test(println)
        //test(fun)
    }
}
