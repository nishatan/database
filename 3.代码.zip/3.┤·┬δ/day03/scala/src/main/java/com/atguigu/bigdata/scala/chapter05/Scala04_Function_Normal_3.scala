package com.atguigu.bigdata.scala.chapter05

object Scala04_Function_Normal_3 {

    def main(args: Array[String]): Unit = {

//        def test( password:String = "000000", name:String* ): Unit = {
//
//        }
//        // 可变参数和参数默认值是不能联合声明
//       // test()
//        test("000000")
//        test("000000", "zhangsan")
//        test("000000", "zhangsan", "lisi")
    }
}
