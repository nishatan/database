package com.atguigu.bigdata.scala.chapter05

object Scala06_Function_Hell_7 {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 地狱版
        // TODO 3. 将函数作为返回值返回, 一般应用于将内部的函数在外部使用
        // 这种方式不推荐自己定义类型
//        def outer() = {
//            def inner(): Unit = {
//                println("inner...")
//            }
//            inner _
//        }
//
//        outer()()

        def outer() = {
            def mid() = {
                def inner(): Unit = {
                    println("inner...")
                }
                inner _
            }
            mid _
        }
        outer()()()
    }
}
