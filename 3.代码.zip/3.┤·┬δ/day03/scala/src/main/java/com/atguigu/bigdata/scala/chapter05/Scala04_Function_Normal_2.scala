package com.atguigu.bigdata.scala.chapter05

object Scala04_Function_Normal_2 {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程
        // TODO 4. 带名参数:传递参数时，增加参数的名称，用于改变传参的顺序
        def fun4( password:String = "000000", name:String  ): Unit = {

        }

        // 参数在传递时默认为顺序匹配。
        // scala可以通过特殊的语法改变传值的顺序
        fun4(name="zhangsan")
    }
}
