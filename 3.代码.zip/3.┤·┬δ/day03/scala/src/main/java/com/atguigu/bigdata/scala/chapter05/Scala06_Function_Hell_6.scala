package com.atguigu.bigdata.scala.chapter05

object Scala06_Function_Hell_6 {

    def main(args: Array[String]): Unit = {

        // TODO 函数式编程 - 地狱版
        // TODO 3. 将函数作为返回值返回
        /*
           public User getUser() {
              return new User();
           }
         */
        def test(): Unit = {
            println("function...")
        }

        def fun() = {
            test _
        }

        //val f = fun _
        //val ff = f()
        //ff()

        fun()()

        test()

    }
}
